import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Star, Quote, MessageCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import heroBg from "@/assets/hero-bg.jpg";

const testimonials = [
  { name: "Mariana S.", text: "O bolo ficou simplesmente perfeito! Todo mundo elogiou. Super recomendo!" },
  { name: "Carlos R.", text: "Encomendei para o aniversário da minha filha e ela amou. Lindo e delicioso!" },
  { name: "Juliana M.", text: "Atendimento maravilhoso, entrega no prazo e sabor incrível. Já sou cliente fiel!" },
  { name: "Amanda L.", text: "O naked cake de morango é divino! Virou tradição nas nossas comemorações." },
];

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroBg} alt="Bolos e doces Lua Doces" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-foreground/40" />
        </div>
        <div className="relative container flex flex-col items-center justify-center text-center py-32 md:py-44">
          <h1 className="font-display text-4xl md:text-6xl font-bold text-primary-foreground mb-4 animate-fade-in">
            Lua Doces
          </h1>
          <p className="text-primary-foreground/90 text-lg md:text-xl max-w-md mb-8 font-light animate-fade-in" style={{ animationDelay: "0.15s" }}>
            Doçura artesanal para os momentos mais especiais da sua vida
          </p>
          <Button variant="hero" size="lg" asChild className="animate-fade-in rounded-full px-8" style={{ animationDelay: "0.3s" }}>
            <Link to="/monteseubolo">Monte Seu Bolo</Link>
          </Button>
        </div>
      </section>


      {/* Testimonials */}
      <section className="bg-secondary py-16 md:py-24">
        <div className="container">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-foreground text-center mb-12">
            O Que Dizem Nossos Clientes
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={i}
                className="bg-card rounded-lg p-6 shadow-sm border flex flex-col"
              >
                <Quote size={20} className="text-primary/40 mb-3" />
                <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                  "{t.text}"
                </p>
                <div className="mt-4 flex items-center gap-1">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} size={14} className="fill-gold text-gold" />
                  ))}
                </div>
                <p className="text-sm font-medium text-foreground mt-2">{t.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container py-16 md:py-24 text-center">
        <div className="bg-rose-light rounded-2xl p-10 md:p-16 max-w-2xl mx-auto">
          <h2 className="font-display text-2xl md:text-3xl font-semibold text-foreground mb-4">
            Pronto para encomendar?
          </h2>
          <p className="text-muted-foreground mb-6">
            Monte o bolo dos seus sonhos em poucos passos.
          </p>
          <Button variant="hero" size="lg" asChild className="rounded-full px-8">
            <Link to="/monteseubolo">Começar Agora</Link>
          </Button>
        </div>
      </section>

      {/* Floating WhatsApp Button */}
      <a
        href="https://wa.me/5571988298103"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 w-14 h-14 bg-[#25D366] hover:bg-[#1ebe5b] text-white rounded-full flex items-center justify-center shadow-lg transition-transform hover:scale-110"
        aria-label="Fale conosco no WhatsApp"
      >
        <MessageCircle size={26} />
      </a>

      <Footer />
    </div>
  );
};

export default Index;
