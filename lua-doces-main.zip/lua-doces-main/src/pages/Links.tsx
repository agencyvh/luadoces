import { ExternalLink, MessageCircle, Globe, Cake, Cookie, PieChart } from "lucide-react";
import logo from "@/assets/logo.png";

const links = [
  {
    label: "Fazer Encomenda",
    href: "https://wa.me/5571988298103?text=Ol%C3%A1!%20Gostaria%20de%20fazer%20uma%20encomenda%20%F0%9F%8E%82",
    icon: MessageCircle,
    external: true,
    accent: true,
  },
  {
    label: "Nosso Site",
    href: "/",
    icon: Globe,
    external: false,
  },
  {
    label: "Catálogo de Bolos",
    href: "/monteseubolo",
    icon: Cake,
    external: false,
  },
  {
    label: "Catálogo de Doces",
    href: "/doces",
    icon: Cookie,
    external: false,
  },
  {
    label: "Catálogo de Tortas",
    href: "/tortas",
    icon: PieChart,
    external: false,
  },
];

const Links = () => {
  return (
    <div className="min-h-screen bg-secondary flex flex-col items-center justify-center px-4 py-12">
      <img src={logo} alt="Lua Doces" className="w-28 h-28 object-contain mb-3" />
      <h1 className="font-display text-2xl font-semibold text-foreground mb-1">Lua Doces</h1>
      <p className="text-muted-foreground text-sm mb-8">Doces finos, tradicionais e brigadeiro gourmet</p>

      <div className="w-full max-w-sm space-y-3">
        {links.map((link) => {
          const Icon = link.icon;
          const className = `w-full flex items-center justify-center gap-3 py-3.5 px-6 rounded-full font-medium text-sm transition-all shadow-sm hover:shadow-md hover:scale-[1.02] ${
            link.accent
              ? "bg-[#25D366] hover:bg-[#1ebe5b] text-white"
              : "bg-card border border-border text-foreground hover:border-primary/40"
          }`;

          if (link.external) {
            return (
              <a
                key={link.label}
                href={link.href}
                target="_blank"
                rel="noopener noreferrer"
                className={className}
              >
                <Icon size={18} />
                {link.label}
                <ExternalLink size={14} className="opacity-50" />
              </a>
            );
          }

          return (
            <a key={link.label} href={link.href} className={className}>
              <Icon size={18} />
              {link.label}
            </a>
          );
        })}
      </div>

      <p className="text-muted-foreground text-xs mt-10">© Lua Doces • @lua.doces02 • (71) 98829-8103</p>
    </div>
  );
};

export default Links;
