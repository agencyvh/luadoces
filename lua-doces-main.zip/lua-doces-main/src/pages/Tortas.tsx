import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { MessageCircle } from "lucide-react";

const tortas = [
  { label: "Torta 16cm", price: 135 },
  { label: "Torta 20cm", price: 200 },
  { label: "Torta 25cm", price: 250 },
];

const Tortas = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 container py-8 md:py-16">
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-center mb-2">
          Tortas
        </h1>
        <p className="text-muted-foreground text-center mb-12">
          Nossas tortas artesanais feitas com carinho
        </p>

        <section className="mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {tortas.map((t) => (
              <div
                key={t.label}
                className="bg-card border rounded-lg overflow-hidden group hover:shadow-md transition-shadow"
              >
                <div className="aspect-[4/3] bg-rose-light flex items-center justify-center">
                  <span className="font-display text-3xl text-primary/30">🍰</span>
                </div>
                <div className="p-5">
                  <h3 className="font-medium text-foreground mb-1">{t.label}</h3>
                  <p className="text-primary font-semibold">
                    R$ {t.price.toFixed(2).replace(".", ",")}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* WhatsApp CTA */}
        <div className="text-center mt-8 mb-4">
          <p className="text-muted-foreground mb-4">
            Gostou? Faça sua encomenda pelo WhatsApp!
          </p>
          <a
            href="https://wa.me/5571988298103?text=Ol%C3%A1!%20Gostaria%20de%20encomendar%20uma%20torta%20%F0%9F%8D%B0"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5b] text-white font-semibold px-8 py-3.5 rounded-full text-base shadow-lg transition-transform hover:scale-105"
          >
            <MessageCircle size={20} />
            Encomendar pelo WhatsApp
          </a>
          <p className="text-muted-foreground text-sm mt-2">(71) 98829-8103</p>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Tortas;
