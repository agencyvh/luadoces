import { useState } from "react";
import { MessageCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ChevronDown } from "lucide-react";
import cakeTradicional from "@/assets/cake-tradicional.jpg";
import cakeChantininho from "@/assets/cake-chantininho.jpg";
import cakeAndar from "@/assets/cake-andar.jpg";
import massaChocolate from "@/assets/massa-chocolate.jpg";
import massaBaunilha from "@/assets/massa-baunilha.jpg";
import massaAmanteigada from "@/assets/massa-amanteigada.jpg";
import recheioPrestigio from "@/assets/recheio-prestigio.jpg";
import recheioChocolate from "@/assets/recheio-chocolate.jpg";
import recheioCasadinho from "@/assets/recheio-casadinho.jpg";
import recheioMaracuja from "@/assets/recheio-maracuja.jpg";
import recheioNinho from "@/assets/recheio-ninho.jpg";
import recheioBejinho from "@/assets/recheio-beijinho.jpg";
import recheioAmeixa from "@/assets/recheio-ameixa.jpg";
import recheioMorango from "@/assets/recheio-morango.jpg";
import recheioOlhoDeSogra from "@/assets/recheio-olhodesogra.jpg";
import recheioAmendoim from "@/assets/recheio-amendoim.jpg";
import recheioNinhoMorango from "@/assets/recheio-ninhomorango.jpg";

const massas = [
  { name: "Chocolate", image: massaChocolate },
  { name: "Baunilha", image: massaBaunilha },
  { name: "Amanteigada", image: massaAmanteigada },
];

const recheios = [
  { name: "Prestígio", image: recheioPrestigio },
  { name: "Chocolate", image: recheioChocolate },
  { name: "Casadinho", image: recheioCasadinho },
  { name: "Maracujá", image: recheioMaracuja },
  { name: "Ninho", image: recheioNinho },
  { name: "Beijinho", image: recheioBejinho },
  { name: "Ameixa", image: recheioAmeixa },
  { name: "Morango", image: recheioMorango },
  { name: "Olho de Sogra", image: recheioOlhoDeSogra },
  { name: "Amendoim", image: recheioAmendoim },
  { name: "Ninho com Morango", image: recheioNinhoMorango, extra: true },
];

const cakeTypes = [
  {
    id: "tradicional",
    label: "Bolo Tradicional / Naked",
    description: "Camadas aparentes com cobertura rústica e frutas frescas",
    image: cakeTradicional,
    sizes: [
      { label: "16cm", price: 100, serves: "~10 fatias" },
      { label: "20cm", price: 185, serves: "~20 fatias" },
      { label: "25cm", price: 215, serves: "~30 fatias" },
    ],
    gallery: [cakeTradicional, cakeTradicional, cakeTradicional],
  },
  {
    id: "chantininho",
    label: "Bolo Chantininho",
    description: "Acabamento liso e delicado em chantilly, perfeito para decorações",
    image: cakeChantininho,
    sizes: [
      { label: "16cm", price: 160, serves: "~10 fatias" },
      { label: "20cm", price: 230, serves: "~20 fatias" },
      { label: "25cm", price: 300, serves: "~30 fatias" },
      { label: "30cm", price: 390, serves: "~40 fatias" },
    ],
    gallery: [cakeChantininho, cakeChantininho, cakeChantininho],
  },
  {
    id: "andar",
    label: "Bolo de Andar (Chantininho)",
    description: "Dois andares elegantes, ideal para grandes celebrações",
    image: cakeAndar,
    sizes: [
      { label: "50 a 55 fatias", price: 440, serves: "50–55 fatias" },
      { label: "75 a 80 fatias", price: 580, serves: "75–80 fatias" },
    ],
    gallery: [cakeAndar, cakeAndar, cakeAndar],
  },
];

const GalleryCarousel = ({ images, alt }: { images: string[]; alt: string }) => {
  const [current, setCurrent] = useState(0);

  return (
    <div className="relative w-full">
      <div className="flex gap-2 overflow-x-auto pb-2 snap-x snap-mandatory scrollbar-hide">
        {images.map((img, i) => (
          <img
            key={i}
            src={img}
            alt={`${alt} - exemplo ${i + 1}`}
            onClick={() => setCurrent(i)}
            className={`w-24 h-24 rounded-lg object-cover shrink-0 snap-start cursor-pointer border-2 transition-all ${
              i === current ? "border-primary" : "border-transparent opacity-70"
            }`}
          />
        ))}
      </div>
      <img
        src={images[current]}
        alt={`${alt} - destaque`}
        className="w-full rounded-lg aspect-[4/3] object-cover mt-2"
      />
      <p className="text-xs text-muted-foreground mt-1 italic">Mais fotos em breve!</p>
    </div>
  );
};

const MonteSeubolo = () => {
  const [openTypeId, setOpenTypeId] = useState<string | null>(null);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 container py-8 md:py-16 max-w-2xl mx-auto">
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-center mb-2">
          Monte Seu Bolo
        </h1>
        <p className="text-muted-foreground text-center mb-10">
          Saiba cada detalhe do seu bolo perfeito
        </p>

        <div className="space-y-3">
          {cakeTypes.map((t) => {
            const isOpen = openTypeId === t.id;
            return (
              <div
                key={t.id}
                className={`rounded-xl border-2 overflow-hidden transition-all ${
                  isOpen ? "border-primary shadow-md" : "border-border hover:border-primary/40"
                }`}
              >
                <button
                  onClick={() => setOpenTypeId(isOpen ? null : t.id)}
                  className="w-full flex items-center gap-4 p-4 bg-card text-left"
                >
                  <img src={t.image} alt={t.label} className="w-16 h-16 rounded-lg object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <span className="block font-medium text-foreground">{t.label}</span>
                    <span className="block text-xs text-muted-foreground mt-0.5">{t.description}</span>
                  </div>
                  <ChevronDown
                    size={20}
                    className={`text-muted-foreground shrink-0 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
                  />
                </button>

                <div
                  className={`grid transition-all duration-300 ease-in-out ${
                    isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                  }`}
                >
                  <div className="overflow-hidden">
                    <div className="px-4 pb-4 pt-2 border-t border-border/50 space-y-5">

                      {/* 1. Gallery */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-2 font-medium uppercase tracking-wide">
                          📸 Exemplos
                        </p>
                        <GalleryCarousel images={t.gallery} alt={t.label} />
                      </div>

                      {/* 2. Sizes & Prices */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-2 font-medium uppercase tracking-wide">
                          📏 Tamanhos e Preços
                        </p>
                        <div className="grid grid-cols-2 gap-2">
                          {t.sizes.map((s) => (
                            <div key={s.label} className="p-3 rounded-lg border border-border bg-background text-center">
                              <span className="block font-medium text-foreground text-sm">{s.label}</span>
                              <span className="block text-xs text-muted-foreground mt-0.5">{s.serves}</span>
                              <span className="block text-sm text-primary font-semibold mt-1">
                                R$ {s.price.toFixed(2).replace(".", ",")}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* 3. Massas */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-2 font-medium uppercase tracking-wide">
                          🍰 Massas Disponíveis
                        </p>
                        <div className="grid grid-cols-3 gap-3">
                          {massas.map((m) => (
                            <div key={m.name} className="flex flex-col items-center gap-1.5">
                              <img src={m.image} alt={m.name} className="w-14 h-14 rounded-full object-cover border-2 border-border" />
                              <span className="text-xs text-foreground font-medium text-center">{m.name}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* 4. Recheios */}
                      <div>
                        <p className="text-xs text-muted-foreground mb-2 font-medium uppercase tracking-wide">
                          🍫 Recheios Disponíveis
                        </p>
                        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                          {recheios.map((r) => (
                            <div key={r.name} className="flex flex-col items-center gap-1.5">
                              <img src={r.image} alt={r.name} className="w-12 h-12 rounded-full object-cover border-2 border-border" />
                              <span className="text-xs text-foreground font-medium text-center leading-tight">{r.name}</span>
                              {r.extra && (
                                <span className="text-[10px] bg-accent text-accent-foreground px-1.5 py-0.5 rounded-full">
                                  + adicional
                                </span>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* WhatsApp CTA */}
        <div className="text-center mt-12 mb-4">
          <p className="text-muted-foreground mb-4">
            Gostou? Faça sua encomenda pelo WhatsApp!
          </p>
          <a
            href="https://wa.me/5571988298103?text=Ol%C3%A1!%20Gostaria%20de%20encomendar%20um%20bolo%20%F0%9F%8E%82"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe5b] text-white font-semibold px-8 py-3.5 rounded-full text-base shadow-lg transition-transform hover:scale-105"
          >
            <MessageCircle size={20} />
            Encomendar pelo WhatsApp
          </a>
          <p className="text-muted-foreground text-sm mt-2">(71) 98829-8103</p>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default MonteSeubolo;
