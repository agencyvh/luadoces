import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

import imgBrigadeiro from "@/assets/doce-brigadeiro.jpg";
import imgCasadinho from "@/assets/doce-casadinho.jpg";
import imgBeijinho from "@/assets/doce-beijinho.jpg";
import imgMoranguinho from "@/assets/doce-moranguinho.jpg";
import imgUvaCoberta from "@/assets/doce-uva-coberta.jpg";
import imgBrigadeiroBranco from "@/assets/doce-brigadeiro-branco.jpg";
import imgNinhoNutella from "@/assets/doce-ninho-nutella.jpg";
import imgBrigadeiroBelga from "@/assets/doce-brigadeiro-belga.jpg";
import imgChurros from "@/assets/doce-churros.jpg";
import imgNapolitano from "@/assets/doce-napolitano.jpg";
import imgFerrero from "@/assets/doce-ferrero.jpg";
import imgPacoca from "@/assets/doce-pacoca.jpg";
import imgAmendoim from "@/assets/doce-amendoim.jpg";
import imgNozes from "@/assets/doce-nozes.jpg";
import imgCastanha from "@/assets/doce-castanha.jpg";
import imgAmeixa from "@/assets/doce-ameixa.jpg";
import imgCereja from "@/assets/doce-cereja.jpg";
import imgMaracuja from "@/assets/doce-maracuja.jpg";
import imgUvaFino from "@/assets/doce-uva-fino.jpg";
import imgPrestigio from "@/assets/doce-prestigio.jpg";
import imgSonhoValsa from "@/assets/doce-sonho-valsa.jpg";
import imgAmendoimFino from "@/assets/doce-amendoim-fino.jpg";

interface Doce {
  name: string;
  image: string;
}

interface Secao {
  title: string;
  price: string;
  items: Doce[];
}

const secoes: Secao[] = [
  {
    title: "Doces Tradicionais",
    price: "R$ 1,30 a unidade",
    items: [
      { name: "Brigadeiro", image: imgBrigadeiro },
      { name: "Casadinho", image: imgCasadinho },
      { name: "Beijinho", image: imgBeijinho },
      { name: "Moranguinho", image: imgMoranguinho },
      { name: "Uva Coberta", image: imgUvaCoberta },
    ],
  },
  {
    title: "Doces Gourmet",
    price: "R$ 1,60 a unidade",
    items: [
      { name: "Brigadeiro Branco", image: imgBrigadeiroBranco },
      { name: "Ninho com Nutella", image: imgNinhoNutella },
      { name: "Brigadeiro Belga", image: imgBrigadeiroBelga },
      { name: "Churros", image: imgChurros },
      { name: "Napolitano", image: imgNapolitano },
      { name: "Ferrero Rocher", image: imgFerrero },
      { name: "Paçoca", image: imgPacoca },
      { name: "Amendoim", image: imgAmendoim },
    ],
  },
  {
    title: "Doces Finos",
    price: "R$ 2,00 a unidade",
    items: [
      { name: "Nozes", image: imgNozes },
      { name: "Castanha", image: imgCastanha },
      { name: "Ameixa", image: imgAmeixa },
      { name: "Cereja", image: imgCereja },
      { name: "Maracujá", image: imgMaracuja },
      { name: "Uva Coberta", image: imgUvaFino },
      { name: "Prestígio", image: imgPrestigio },
      { name: "Sonho de Valsa", image: imgSonhoValsa },
      { name: "Amendoim", image: imgAmendoimFino },
    ],
  },
];

const Doces = () => {
  const handleWhatsApp = () => {
    const msg = encodeURIComponent(
      "Olá! Gostaria de encomendar doces da Lua Doces!"
    );
    window.open(`https://wa.me/5571988298103?text=${msg}`, "_blank");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 container py-8 md:py-16">
        <h1 className="font-display text-3xl md:text-4xl font-semibold text-center mb-2">
          Nossos Doces
        </h1>
        <p className="text-muted-foreground text-center mb-12">
          Delícias artesanais feitas com ingredientes selecionados
        </p>

        {secoes.map((secao) => (
          <section key={secao.title} className="mb-16">
            <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 mb-6">
              <h2 className="font-display text-2xl font-medium">{secao.title}</h2>
              <span className="text-primary font-semibold text-lg">{secao.price}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {secao.items.map((doce) => (
                <div
                  key={doce.name}
                  className="bg-card border rounded-xl overflow-hidden group hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                >
                  <div className="aspect-square overflow-hidden">
                    <img
                      src={doce.image}
                      alt={doce.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-3 text-center">
                    <h3 className="font-medium text-foreground text-sm leading-tight">
                      {doce.name}
                    </h3>
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}

        {/* WhatsApp CTA */}
        <div className="text-center mt-8 mb-4">
          <p className="text-muted-foreground mb-4">
            Gostou? Faça sua encomenda pelo WhatsApp!
          </p>
          <Button
            variant="whatsapp"
            size="lg"
            className="rounded-full text-base px-8"
            onClick={handleWhatsApp}
          >
            <MessageCircle size={20} />
            Encomendar pelo WhatsApp
          </Button>
          <p className="text-muted-foreground text-sm mt-2">(71) 98829-8103</p>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Doces;
