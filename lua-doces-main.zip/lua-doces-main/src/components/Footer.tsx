import { Instagram, MessageCircle, CreditCard, Banknote, Smartphone } from "lucide-react";

const Footer = () => (
  <footer className="bg-secondary border-t mt-16">
    <div className="container py-12">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Brand */}
        <div>
          <h3 className="font-display text-xl font-semibold text-foreground mb-2">Lua Doces</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Doces feitos com carinho para tornar seus momentos ainda mais especiais.
          </p>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-display text-lg font-medium text-foreground mb-3">Contato</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>
              <a
                href="https://instagram.com/lua.doces02"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 hover:text-primary transition-colors"
              >
                <Instagram size={16} /> @lua.doces02
              </a>
            </li>
            <li>
              <a
                href="https://wa.me/5571988298103"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 hover:text-primary transition-colors"
              >
                <MessageCircle size={16} /> (71) 98829-8103
              </a>
            </li>
          </ul>
        </div>

        {/* Payment */}
        <div>
          <h4 className="font-display text-lg font-medium text-foreground mb-3">Pagamento</h4>
          <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5 bg-background px-3 py-1.5 rounded-full">
              <Smartphone size={14} /> Pix
            </span>
            <span className="inline-flex items-center gap-1.5 bg-background px-3 py-1.5 rounded-full">
              <Banknote size={14} /> Dinheiro
            </span>
            <span className="inline-flex items-center gap-1.5 bg-background px-3 py-1.5 rounded-full">
              <CreditCard size={14} /> Cartões
            </span>
          </div>
        </div>
      </div>

      <div className="border-t mt-8 pt-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Lua Doces. Todos os direitos reservados.
      </div>
    </div>
  </footer>
);

export default Footer;
